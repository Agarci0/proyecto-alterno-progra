public interface Arma {
    int atacar();
}

class Espada implements Arma {
    @Override
    public int atacar() {
        return 10;
    }
}

class ArcoYFlecha implements Arma {
    @Override
    public int atacar() {
        return 7;
    }
}

class Hacha implements Arma {
    @Override
    public int atacar() {
        return 8;
    }
}

class Cuchillo implements Arma {
    @Override
    public int atacar() {
        return 6;
    }
}

