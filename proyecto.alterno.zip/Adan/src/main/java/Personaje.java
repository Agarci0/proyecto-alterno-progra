public abstract class Personaje {
    protected Arma arma;
    protected int poderBase;

    public Personaje(Arma arma, int poderBase) {
        this.arma = arma;
        this.poderBase = poderBase;
    }

    public void cambiarArma(Arma nuevaArma) {
        this.arma = nuevaArma;
    }

    public int atacar() {
        return poderBase + arma.atacar();
    }

    public abstract String getTipoPersonaje();
}

class Rey extends Personaje {
    public Rey(Arma arma) {
        super(arma, 5);
    }

    @Override
    public String getTipoPersonaje() {
        return "Rey";
    }
}

class Reina extends Personaje {
    public Reina(Arma arma) {
        super(arma, 4);
    }

    @Override
    public String getTipoPersonaje() {
        return "Reina";
    }
}

class Caballero extends Personaje {
    public Caballero(Arma arma) {
        super(arma, 3);
    }

    @Override
    public String getTipoPersonaje() {
        return "Caballero";
    }
}

class Gnomo extends Personaje {
    public Gnomo(Arma arma) {
        super(arma, 2);
    }

    @Override
    public String getTipoPersonaje() {
        return "Gnomo";
    }
}
